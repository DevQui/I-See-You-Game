<?php
$currplayer = $_POST["player"];
echo $currplayer;
exit();
?>